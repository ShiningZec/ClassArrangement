# from src.cli import cli_util
from src.app import ui

__author__ = 'ShiningZec'


def main():
    # cli_util.main()
    ui.main()


if __name__ == "__main__":
    main()
