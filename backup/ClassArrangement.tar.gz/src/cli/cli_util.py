__author__ = 'ShiningZec'

from .cli_doc import (MDOC, SEP_EQUAL, SEP_MINUS, TABLE_TITLE)
from src.core.schedule_util import Course, CourseScheduler, ScheduleVisualizer
from checker import checker

from dataclasses import dataclass
from typing import List

COURSE_FILE = "data\\course.json"
OUTPUT_FILE = "data\\schedule.json"
DEFAULT_MIN_CREDIT = 100


@dataclass
class Config:
    course_file: str = COURSE_FILE
    schedule_file: str = OUTPUT_FILE
    forbid_time: List[int] = None
    class_limit: int = 200
    credit_limit: int = 5000
    enable_required: bool = False
    enable_forbid_time: bool = False
    enable_limit_class: bool = False
    enable_limit_credit: bool = False


class Cli:

    def __init__(self,
                 *,
                 course_file: str = COURSE_FILE,
                 output_file: str = OUTPUT_FILE,
                 cs: CourseScheduler = None):
        self.config: Config = Config(course_file=course_file,
                                     schedule_file=output_file,
                                     forbid_time=[0 for _ in range(7)])
        self.course_file = course_file
        self.output_file = output_file
        if cs is None:
            self.cs: CourseScheduler = CourseScheduler(
                course_file=self.course_file)
        else:
            self.cs = cs
        self.sv: ScheduleVisualizer = None

    def mainloop(self):
        try:
            print(MDOC[0])
            while (1):  # Main Menu
                print(MDOC[1])
                buff: str = input(">> ")
                if not buff:
                    continue
                choice: str = buff.strip()[0]

                if choice == '1':  # Init Menu
                    while (1):
                        print(MDOC[2])
                        buff: str = input(">> ")
                        if not buff:
                            continue
                        choice: str = buff.strip()[0]
                        if choice == '1' or choice == '2':
                            try:
                                self.cs: CourseScheduler = CourseScheduler(
                                    course_file=self.course_file)
                                self.sv: ScheduleVisualizer = None
                                print("Success.")
                            except Exception:
                                print("Failing: Lack of Config.")
                        elif choice == '0':
                            break
                        elif choice == '*':
                            continue
                        else:
                            print(f"Bad Choice Input: {choice}")

                elif choice == '2':  # Operate Menu
                    while (1):
                        print(MDOC[3])
                        buff: str = input(">> ")
                        if not buff:
                            continue
                        choice: str = buff.strip()[0]
                        if choice == '1':
                            config: Config = self.config
                            buff: str = input(
                                "Input min_credits(default: 100):\n>> ")
                            if buff:
                                try:
                                    min_credit = int(buff.strip())
                                except Exception:
                                    min_credit = DEFAULT_MIN_CREDIT
                            else:
                                min_credit = DEFAULT_MIN_CREDIT
                            try:
                                if config.enable_forbid_time:
                                    self.cs.set_forbidden_times(
                                        config.forbid_time)
                                else:
                                    self.cs.set_forbidden_times(
                                        [0 for _ in range(7)])
                                self.cs.schedule_courses(
                                    min_credits=min_credit,
                                    output_file=config.schedule_file,
                                    enable_required=config.enable_required,
                                    class_limit_per_sem=config.class_limit
                                    if config.enable_limit_class else 200,
                                    credit_limit_per_sem=config.credit_limit
                                    if config.enable_limit_credit else 5000)
                                self.sv = ScheduleVisualizer(
                                    course_file=config.course_file,
                                    schedule_file=config.schedule_file,
                                    cs=self.cs)
                                print("Success: output "
                                      f"at {config.schedule_file}")
                            except Exception:
                                print("Failing: Can not generate schedule.")
                        elif choice == '2':
                            if self.sv is None:
                                print(
                                    "Bad Option: Must generate schedule first."
                                )
                                continue
                            buff: str = input(
                                "Input semester to visualize(default: 1):\n>> "
                            )
                            if buff:
                                try:
                                    semester_idx = int(buff.strip()) - 1
                                    if semester_idx < 0 or semester_idx > 7:
                                        semester_idx = 0
                                except Exception:
                                    semester_idx = 0
                            else:
                                semester_idx = 0
                            try:
                                self.visualize(semester_idx)
                                print("Success.")
                            except Exception:
                                print("Failing: Can not visualize schedule.")
                            pass
                        elif choice == '3':
                            if self.sv is None:
                                print(
                                    "Bad Option: Must generate schedule first."
                                )
                                continue
                            config: Config = self.config
                            checker.main(course_file=config.course_file,
                                         schedule_file=config.schedule_file)
                        elif choice == '0':
                            break
                        elif choice == '*':
                            continue
                        else:
                            print(f"Bad Choice Input: {choice}")
                elif choice == '3':
                    while (1):
                        print(MDOC[4])
                        print("Not Completed.")
                        break
                    pass  # TODO
                elif choice == '4':
                    while (1):
                        print(MDOC[5])
                        buff: str = input(">> ")
                        if not buff:
                            continue
                        choice: str = buff.strip()[0]
                        if choice == '1':
                            self.submenu_set()
                        elif choice == '2':
                            self.submenu_toggle()
                        elif choice == '0':
                            break
                        elif choice == '*':
                            continue
                        else:
                            print(f"Bad Choice Input: {choice}")
                elif choice == '0':
                    break
                elif choice == '*':
                    continue
                else:
                    print(f"Bad Choice Input: {choice}")
            print(MDOC[-1])
        except KeyboardInterrupt:
            print()
            print(MDOC[-1])
        print()

    def submenu_set(self):
        while (1):
            print(MDOC[6])
            buff: str = input(">> ")
            if not buff:
                continue
            choice: str = buff.strip()[0]
            if choice == '1':
                buff: str = input("Please input course file path "
                                  "(format: path\\to\\file):\n>> ")
                if not buff:
                    print("Cancelled from setting course file path")
                else:
                    self.config.course_file = buff.strip()
                    print("Successfully changed course "
                          f"file path to \n{self.config.course_file}")
            elif choice == '2':
                buff: str = input("Please input schedule file path "
                                  "(format: path\\to\\file):\n>> ")
                if not buff:
                    print("Cancelled from setting schedule file path")
                else:
                    self.config.schedule_file = buff.strip()
                    print("Successfully changed schedule "
                          f"file path to \n{self.config.schedule_file}")
            elif choice == '3':
                buff: str = input("Please input forbid time (format: "
                                  "7 integers split by space):\n>> ")
                if not buff:
                    print("Cancelled from setting forbid time")
                    continue
                try:
                    timelist_str: List[str] = buff.strip().split(' ')[:7]
                    self.config.forbid_time = [
                        int(item) for item in timelist_str
                    ]
                    while len(self.config.forbid_time) < 7:
                        self.config.forbid_time.append(0)
                    print("Successfully changed forbid time "
                          f"to \n{self.config.forbid_time}")
                except Exception:
                    print("Failing: Unable to change forbid time")
            elif choice == '4':
                buff: str = input("Please input ClassPerSemLimit (format: "
                                  "1 integer):\n>> ")
                if not buff:
                    print("Cancelled from setting ClassPerSemLimit")
                    continue
                try:
                    self.config.class_limit = int(buff.strip().split(' ')[0])
                    print("Successfully changed ClassPerSemLimit "
                          f"to \n{self.config.class_limit}")
                except Exception:
                    print("Failing: Unable to change ClassPerSemLimit")
            elif choice == '5':
                buff: str = input("Please input CreditPerSemLimit (format: "
                                  "1 integer):\n>> ")
                if not buff:
                    print("Cancelled from setting CreditPerSemLimit")
                    continue
                try:
                    self.config.credit_limit = int(buff.strip().split(' ')[0])
                    print("Successfully changed CreditPerSemLimit "
                          f"to \n{self.config.credit_limit}")
                except Exception:
                    print("Failing: Unable to change CreditPerSemLimit")
            elif choice == '0':
                break
            elif choice == '*':
                continue
            else:
                print(f"Bad Choice: {choice}")

    def submenu_toggle(self):  # TODO: Enable Priority
        config: Config = self.config
        while (1):
            print(MDOC[7])
            buff: str = input(">> ")
            if not buff:
                continue
            choice: str = buff.strip()[0]
            if choice == '1':
                print("Config Require was primally "
                      f"{"Enabled" if config.enable_required else "Disabled"}"
                      " and is now set to "
                      f"{"Disabled" if config.enable_required else "Enabled"}"
                      )
                config.enable_required = not config.enable_required
            elif choice == '2':
                print("Config ForbidTime was primally "
                      f"{"Enabled" if (
                          config.enable_forbid_time) else "Disabled"}"
                      " and is now set to "
                      f"{"Disabled" if (
                          config.enable_forbid_time) else "Enabled"}"
                      )
                config.enable_forbid_time = not config.enable_forbid_time
            elif choice == '3':
                print("Config LimitClassPerSem was primally "
                      f"{"Enabled" if (
                          config.enable_limit_class) else "Disabled"}"
                      " and is now set to "
                      f"{"Disabled" if (
                          config.enable_limit_class) else "Enabled"}"
                      )
                config.enable_limit_class = not config.enable_limit_class
            elif choice == '4':
                print("Config LimitCreditPerSem was primally "
                      f"{"Enabled" if (
                          config.enable_limit_credit) else "Disabled"}"
                      " and is now set to "
                      f"{"Disabled" if (
                          config.enable_limit_credit) else "Enabled"}"
                      )
                config.enable_limit_credit = not config.enable_limit_credit
            elif choice == '0':
                self.config = config
                break
            elif choice == '*':
                continue
            else:
                print(f"Bad Choice: {choice}")

    def visualize(self, semester: int = 0):
        courses: List[Course] = self.cs.courses
        schedule_table: List[List[str]] = self.sv.get_schedule_table(
            semester=semester)

        print(SEP_EQUAL)
        print(f"SEM {semester + 1}", TABLE_TITLE, sep='')
        print(SEP_EQUAL)

        for i in range(len(schedule_table[0])):
            print(f"  {i + 1}\t ", end='')
            for j in range(len(schedule_table)):
                course_id = schedule_table[j][i]
                if course_id is not None:
                    course_name = courses[schedule_table[j][i]].name
                    if course_name in ("现代CAD技术（A）", "现代CAD技术（B）", "数学分析II",
                                       "概率论与数理统计A"):
                        print(f"[    {course_name}\t\t]", end='')
                    elif course_name in ("数学分析I"):
                        print(f"[    {course_name}\t\t\t]", end='')
                    elif len(course_name) < 5:
                        print(f"[    {course_name}\t\t\t]", end='')
                    elif len(course_name) < 9:
                        print(f"[    {course_name}\t\t]", end='')
                    elif len(course_name) < 11:
                        print(f"[    {course_name}\t]", end='')
                    else:
                        print(
                            f"[    {course_name[0:8]}...{course_name[-2:]}\t]",
                            end='')
                else:
                    if j >= 5:
                        print("[\t\t]", end='')
                    else:
                        print("[\t\t\t\t]", end='')
            print()
            if i == 4 or i == 9:
                print(SEP_MINUS)
        else:
            print(SEP_EQUAL)


def main():
    cli: Cli = Cli()
    cli.mainloop()
