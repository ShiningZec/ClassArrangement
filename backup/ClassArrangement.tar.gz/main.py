from src.cli import cli_util

__author__ = 'ShiningZec'


def main():
    cli_util.main()


if __name__ == "__main__":
    main()
